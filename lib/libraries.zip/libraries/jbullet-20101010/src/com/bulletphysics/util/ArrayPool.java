package com.bulletphysics.util;
 
import java.util.*;
 
 
/**
 * Object pool for arrays.
 * 
 * @author sean
 */
public abstract class ArrayPool<T>
{
  private final static ThreadLocal<ArrayPool<int[]>> INT_ARRAY_POOL = new ThreadLocal<ArrayPool<int[]>>()
  {
    @Override
    protected ArrayPool<int[]> initialValue()
    {
      return new ArrayPool<int[]>()
      {
        @Override
        protected int getLength(int[] array)
        {
          return array.length;
        }
        @Override
        protected int[] makeTypedArray(int length)
        {
          return new int[length];
        }
      };
    }
  };
  private final static ThreadLocal<ArrayPool<float[]>> FLOAT_ARRAY_POOL = new ThreadLocal<ArrayPool<float[]>>()
  {
    @Override
    protected ArrayPool<float[]> initialValue()
    {
      return new ArrayPool<float[]>()
      {
        @Override
        protected int getLength(float[] array)
        {
          return array.length;
        }
        @Override
        protected float[] makeTypedArray(int length)
        {
          return new float[length];
        }
      };
    }
  };
  private final Queue[] recyclingQueues = new Queue[12]; // 12 elements should be enough for anyone
  protected abstract T makeTypedArray(int length);
  protected abstract int getLength(T array);
  public ArrayPool()
  {
    for (int i = 0; i < recyclingQueues.length; i++)
      recyclingQueues[i] = new LinkedList<T>();
  }
  /**
   * Returns array of exactly the same length as demanded, or create one if not
   * present in the pool.
   * 
   * @param length
   * @return array
   */
  public T getFixed(int length)
  {
    Queue<T> recyclingQueue = recyclingQueues[length];
    T reusableArray;
    if (recyclingQueue.isEmpty())
      reusableArray = makeTypedArray(length);
    else
      reusableArray = recyclingQueue.remove();
    return reusableArray;
  }
 
  /**
   * Releases array into object pool.
   * 
   * @param array previously obtained array from this pool
   */
  public void release(T array)
  {
    Queue<T> recycledArrays = recyclingQueues[getLength(array)];
    recycledArrays.add(array);
  }
   
  /**
   * Returns per-class array pool for given type, or create one if it doesn't exist.
   * 
   * @param cls type
   * @return object pool
   */
  public static <T> ArrayPool<T> get(Class cls)
  {
    if (cls == int.class)
      return (ArrayPool<T>)INT_ARRAY_POOL.get();
    else if (cls == float.class)
      return (ArrayPool<T>)FLOAT_ARRAY_POOL.get();
    else
      throw new IllegalArgumentException("No ArrayPool for " + cls.getCanonicalName());
  }
 
  public static void cleanCurrentThread() { /* does nothing */  }
 
}