package com.bulletphysics.util;
 
import java.util.*;
 
/**
 * Object pool.
 *
 * @author sean
 */
public class ObjectPool<T> {
 
  private final Class<T> cls;
  private final Queue<T> list = new LinkedList<T>();
  private final static Map<Class, ObjectPool> MAP_CLASS_POOL = new HashMap<Class, ObjectPool>();
 
  private ObjectPool(Class<T> cls) { this.cls = cls; }
 
  /**
   * Returns instance from pool, or create one if pool is empty.
   *
   * @return instance
   */
  public synchronized T get() {
      if (!list.isEmpty())
        return list.remove();
    try { return cls.newInstance(); }
    catch (Exception e) { throw new IllegalStateException("Couldn't create a " + cls.getCanonicalName(), e); }
  }
 
  /**
   * Release instance into pool.
   *
   * @param obj previously obtained instance from pool
   */
  public synchronized void release(T obj) {
    list.add(obj);
  }
 
  /**
   * Returns per-class object pool for given type, or create one if it doesn't exist.
   *
   * @param cls type
   * @return object pool
   */
  public synchronized static <T> ObjectPool<T> get(Class<T> cls)
  {
    ObjectPool<T> pool = (ObjectPool<T>)MAP_CLASS_POOL.get(cls);
    if (pool == null) {
      pool = new ObjectPool<T>(cls);
      MAP_CLASS_POOL.put(cls, pool);
    }
 
    return pool;
  }
  public static void cleanCurrentThread() { /* does nothing */ }
}